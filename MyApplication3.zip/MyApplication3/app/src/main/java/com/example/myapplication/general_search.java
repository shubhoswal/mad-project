package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class general_search extends AppCompatActivity {

    private ArrayList<String> userNames; //Received from database
    private TextView Name;
    private Button next;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general_search);
        userNames = new ArrayList<String>();
        userNames.add("user1");
        userNames.add("user2");
        userNames.add("user3");
        display_user_data();
        next=(Button)findViewById(R.id.button11);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v ) {
                next_user();
            }
        });
    }


    public void display_user_data()
    {
        Name=(TextView) findViewById(R.id.textView11);
        String currentUser=userNames.get(0);
        Name.setText(currentUser);
        //TODO- Fetch details of currentUser from database except contact and email id
    }

    public void next_user()
    {
        userNames.remove(0);
        display_user_data();
    }


}
