package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.w3c.dom.Text;

public class profile extends AppCompatActivity {
    private Button saveButton;
    private EditText name;
    private EditText organization;
    private EditText email;
    private EditText contact;
    private EditText age;
    private EditText id;
    private EditText interests;
    private EditText skills;
    private EditText expertiseLevel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        name=(EditText)findViewById(R.id.editText1);
        organization=(EditText)findViewById(R.id.editText2);
        email=(EditText)findViewById(R.id.editText3);
        contact=(EditText)findViewById(R.id.editText4);
        age=(EditText)findViewById(R.id.editText5);
        id=(EditText)findViewById(R.id.editText6);
        interests=(EditText)findViewById(R.id.editText7);
        skills=(EditText)findViewById(R.id.editText8);
        expertiseLevel=(EditText)findViewById(R.id.editText9);
        saveButton = (Button)findViewById(R.id.button_add);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dashboard();
            }
        });
    }

    public void dashboard(){

        //TODO- Update the record in the databse
        Intent intent= new Intent(this, dashboard.class);
        startActivity(intent);
    }
}
